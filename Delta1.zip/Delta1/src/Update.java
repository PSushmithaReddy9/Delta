

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Update
 */
public class Update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Update() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try{
			String aa=request.getParameter("aa");
			String bb=request.getParameter("bb");
			  PrintWriter pw=response.getWriter();
			  Class.forName("oracle.jdbc.OracleDriver");
			  Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","1234");
			  Statement stmt=con.createStatement();
			
			  ResultSet rs=stmt.executeQuery("select * from download where appname="+aa+" and appver="+bb+" ");
			    if(rs.next())
			    {
			    	
			    	
			    	pw.write("no");

			  
			    }else{
			    	
			    	String ss=rs.getString("URL");
			        pw.write(ss);
			    	
			    
			    }
			    }catch(Exception e){
			    	e.printStackTrace();
			    }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
